#!/usr/bin/env python3
"""
Run the exact multi-agent tourism workflow for `MAS prompt férias para LLM local.txt`.

The script uses local Ollama (llama3:latest) and keeps the prompt text verbatim.
It mirrors the agents in the brief and saves outputs beside this file.

Usage: python prompt_3_test/run_prompt3_agents.py
"""
from __future__ import annotations
import argparse
import json
import pathlib
import subprocess
import time
import threading
import urllib.error
import urllib.request
from typing import Dict, List, Optional, Sequence


OLLAMA_ENDPOINT = "http://localhost:11434/api/generate"
MODEL_NAME = "llama3:latest"
WORKDIR = pathlib.Path(__file__).parent.parent
PROMPT_FILE = WORKDIR / "Caso turismo" / "MAS prompt férias para LLM local.txt"
OUTPUT_DIR = pathlib.Path(__file__).parent


def parse_power_readings(raw_value: str) -> List[float]:
    parts = [part.strip() for part in raw_value.split(",") if part.strip()]
    if not parts:
        raise ValueError("empty power reading input")
    return [float(part) for part in parts]


def summarize_power_readings(readings: Sequence[float]) -> Dict[str, float]:
    if not readings:
        raise ValueError("at least one power reading is required")
    power_min = min(readings)
    power_max = max(readings)
    power_avg = sum(readings) / len(readings)
    return {
        "power_min_w": power_min,
        "power_avg_w": power_avg,
        "power_max_w": power_max,
    }


def energy_from_power(power_avg_w: float, elapsed_s: float) -> Dict[str, float]:
    watt_hours = power_avg_w * (elapsed_s / 3600.0)
    return {"wh": watt_hours, "kwh": watt_hours / 1000.0}


def prompt_power_readings(agent_name: str) -> List[float]:
    print()
    print(f"GPU power readings for {agent_name} (W).")
    print("If OpenHardwareMonitor is running with WMI enabled, the script will use GPU power automatically.")
    print("Otherwise enter one or more GPU wattage values separated by commas, for example: 118, 121, 119")
    print("If you only have one stable reading, enter a single number.")
    while True:
        raw_value = input(f"{agent_name} GPU watts: ").strip()
        try:
            return parse_power_readings(raw_value)
        except Exception:
            print("Invalid input. Please enter one or more numeric values separated by commas.")


def load_power_map(power_file: Optional[pathlib.Path]) -> Dict[str, List[float]]:
    if power_file is None:
        return {}
    data = json.loads(power_file.read_text(encoding="utf-8"))
    power_map: Dict[str, List[float]] = {}
    for agent_name, raw_value in data.items():
        if isinstance(raw_value, (int, float)):
            power_map[agent_name] = [float(raw_value)]
        elif isinstance(raw_value, list):
            power_map[agent_name] = [float(item) for item in raw_value]
        elif isinstance(raw_value, str):
            power_map[agent_name] = parse_power_readings(raw_value)
        else:
            raise ValueError(f"Unsupported power value for {agent_name}: {type(raw_value)!r}")
    return power_map


def query_openhardwaremonitor_sensors() -> List[Dict[str, object]]:
    command = [
        "powershell",
        "-NoProfile",
        "-Command",
        (
            "Get-CimInstance -Namespace root\\OpenHardwareMonitor -ClassName Sensor | "
            "Select-Object Name, SensorType, Value, Min, Max, Identifier | ConvertTo-Json -Depth 3"
        ),
    ]
    completed = subprocess.run(command, capture_output=True, text=True, check=True)
    raw_output = completed.stdout.strip()
    if not raw_output:
        return []
    data = json.loads(raw_output)
    if isinstance(data, dict):
        return [data]
    return list(data)


def find_gpu_power_readings_from_ohm() -> Dict[str, List[float]]:
    try:
        sensors = query_openhardwaremonitor_sensors()
    except Exception:
        return {}

    gpu_keywords = ("gpu", "nvidia", "amd", "ati", "radeon")
    power_keywords = ("power", "board power", "gpu power")
    readings_by_agent: Dict[str, List[float]] = {}

    for sensor in sensors:
        name = str(sensor.get("Name", ""))
        sensor_type = str(sensor.get("SensorType", ""))
        identifier = str(sensor.get("Identifier", ""))
        value = sensor.get("Value")
        haystack = f"{name} {sensor_type} {identifier}".lower()
        if not any(keyword in haystack for keyword in gpu_keywords):
            continue
        if not any(keyword in haystack for keyword in power_keywords):
            continue
        if value is None:
            continue
        try:
            numeric_value = float(value)
        except Exception:
            continue
        readings_by_agent.setdefault("gpu", []).append(numeric_value)

    return readings_by_agent


def read_current_gpu_power_watts() -> Optional[float]:
    try:
        sensors = query_openhardwaremonitor_sensors()
    except Exception:
        return None

    gpu_keywords = ("gpu", "nvidia", "amd", "ati", "radeon")
    power_keywords = ("power", "board power", "gpu power")
    values: List[float] = []

    for sensor in sensors:
        name = str(sensor.get("Name", ""))
        sensor_type = str(sensor.get("SensorType", ""))
        identifier = str(sensor.get("Identifier", ""))
        value = sensor.get("Value")
        haystack = f"{name} {sensor_type} {identifier}".lower()
        if not any(keyword in haystack for keyword in gpu_keywords):
            continue
        if not any(keyword in haystack for keyword in power_keywords):
            continue
        if value is None:
            continue
        try:
            values.append(float(value))
        except Exception:
            continue

    if not values:
        return None
    return sum(values) / len(values)


class PowerSampler:
    def __init__(self, interval_s: float = 0.5):
        self.interval_s = interval_s
        self.samples: List[float] = []
        self._stop_event = threading.Event()
        self._thread: Optional[threading.Thread] = None

    def start(self) -> None:
        self._stop_event.clear()
        self.samples = []
        self._thread = threading.Thread(target=self._run, daemon=True)
        self._thread.start()

    def stop(self) -> None:
        self._stop_event.set()
        if self._thread is not None:
            self._thread.join(timeout=max(1.0, self.interval_s * 4))
            self._thread = None

    def _run(self) -> None:
        while not self._stop_event.is_set():
            value = read_current_gpu_power_watts()
            if value is not None:
                self.samples.append(value)
            self._stop_event.wait(self.interval_s)

    def collect_during(self, work_fn):
        self.start()
        try:
            result = work_fn()
        finally:
            self.stop()
        if not self.samples:
            fallback = read_current_gpu_power_watts()
            if fallback is not None:
                self.samples.append(fallback)
        return result, list(self.samples)


def call_ollama(prompt_text: str, timeout: int = 600) -> str:
    payload = {"model": MODEL_NAME, "prompt": prompt_text, "stream": False}
    data = json.dumps(payload).encode("utf-8")
    req = urllib.request.Request(
        OLLAMA_ENDPOINT, data=data, headers={"Content-Type": "application/json"}, method="POST"
    )
    try:
        with urllib.request.urlopen(req, timeout=timeout) as resp:
            body = resp.read().decode("utf-8")
    except urllib.error.HTTPError as e:
        detail = e.read().decode("utf-8", errors="replace")
        raise RuntimeError(f"HTTP {e.code} from Ollama: {detail}") from e
    except urllib.error.URLError as e:
        raise RuntimeError(f"Cannot reach Ollama at {OLLAMA_ENDPOINT}: {e.reason}") from e

    parsed = json.loads(body)
    return parsed.get("response", "")


class Agent:
    def __init__(self, name: str, role_description: str):
        self.name = name
        self.role_description = role_description
        self.messages = 0
        self.total_time = 0.0
        self.power_readings: List[float] = []
        self.power_min_w = 0.0
        self.power_avg_w = 0.0
        self.power_max_w = 0.0
        self.energy_wh = 0.0
        self.energy_kwh = 0.0

    def call(self, task: str, context: str = "") -> str:
        prompt = f"Role: {self.name}\nDescription: {self.role_description}\nTask: {task}\nContext:\n{context}\n\nProvide a clear and concise answer."
        start = time.perf_counter()
        resp = call_ollama(prompt)
        elapsed = time.perf_counter() - start
        self.messages += 1
        self.total_time += elapsed
        return resp.strip()

    def record_power(self, readings: Sequence[float]) -> None:
        summary = summarize_power_readings(readings)
        energy = energy_from_power(summary["power_avg_w"], self.total_time)
        self.power_readings = [float(item) for item in readings]
        self.power_min_w = summary["power_min_w"]
        self.power_avg_w = summary["power_avg_w"]
        self.power_max_w = summary["power_max_w"]
        self.energy_wh = energy["wh"]
        self.energy_kwh = energy["kwh"]


def build_agents() -> Dict[str, Agent]:
    return {
        "orchestrator": Agent("Agente A Orquestrador", "Coordena os agentes e agrega resultados."),
        "biblio": Agent("Agente B Perguntador", "Pergunta os dados em falta ao cliente e, se o cliente estiver aberto a sugestões, prossegue."),
        "cultural": Agent("Agente C Cultural", "Identifica locais culturais relevantes, custos financeiros, melhores horários e custos ambientais de cada deslocação."),
        "natural": Agent("Agente D Natural", "Identifica locais naturais de interesse, como praias, jardins e florestas, e como viajar até lá com custos económicos e ambientais."),
        "hotel": Agent("Agente E Hotel", "Identifica hotel de 3 estrelas com preocupações de sustentabilidade ambiental e inclui o respetivo link online."),
        "flight": Agent("Agente F Avião", "Identifica avião em classe económica, com custos financeiros, custos ambientais, tempo estimado de viagem e horários."),
        "train": Agent("Agente G Comboio", "Identifica uma alternativa de viagem em comboio partindo da Amadora, com custos financeiros, custos ambientais, tempo estimado de viagem e horários."),
    }


def extract_urls(text: str) -> List[str]:
    import re

    return re.findall(r"https?://[^\s)\]]+", text)


def verify_urls(urls: Sequence[str], keywords: Sequence[str]) -> List[Dict[str, str]]:
    results: List[Dict[str, str]] = []
    for url in urls:
        try:
            with urllib.request.urlopen(url, timeout=30) as resp:
                body = resp.read(12000).decode("utf-8", errors="replace")
            haystack = body.lower()
            keyword_match = any(keyword.lower() in haystack for keyword in keywords if keyword)
            results.append({
                "url": url,
                "teste_alucinacao": "sim" if keyword_match or body.strip() else "não",
            })
        except Exception as exc:
            results.append({
                "url": url,
                "teste_alucinacao": f"não ({exc.__class__.__name__})",
            })
    return results


def main():
    parser = argparse.ArgumentParser(description="Run prompt 3 tourism multi-agent workflow with local Ollama.")
    parser.add_argument(
        "--power-file",
        type=pathlib.Path,
        default=None,
        help="Optional JSON file with GPU wattage readings per agent name.",
    )
    parser.add_argument(
        "--force-improve",
        action="store_true",
        help="Force the improver agent to run even if the audit score is above threshold.",
    )
    parser.add_argument(
        "--improve-threshold",
        type=float,
        default=6.0,
        help="Audit score threshold below which the improver runs (default: 6.0).",
    )
    args = parser.parse_args()

    txt = PROMPT_FILE.read_text(encoding="utf-8", errors="replace")
    OUTPUT_DIR.mkdir(parents=True, exist_ok=True)
    agents = build_agents()
    power_map = load_power_map(args.power_file)
    power_sampler = PowerSampler(interval_s=0.5)

    timestamp = time.strftime("%Y%m%d_%H%M%S")
    prompt_snapshot = OUTPUT_DIR / f"prompt3_turismo_prompt_snapshot_{timestamp}.txt"
    prompt_snapshot.write_text(txt, encoding="utf-8")
    print("Saved prompt snapshot to", prompt_snapshot)

    results: Dict[str, str] = {}

    orchestrator = agents["orchestrator"]
    task = (
        "Resume o objetivo da prompt, os requisitos, os limites, os agentes, o relatório de transparência, "
        "os dados de sustentabilidade e a necessidade de links online dos hotéis recomendados."
    )
    orchestration_ctx = txt
    orches_resp, orches_samples = power_sampler.collect_during(lambda: orchestrator.call(task, orchestration_ctx))
    orchestrator.record_power(orches_samples or power_map.get("orchestrator") or prompt_power_readings("orchestrator"))
    results["orchestration"] = orches_resp

    biblio = agents["biblio"]
    task = (
        "Verifica se no texto existem dados suficientes sobre localidade onde vive o cliente, destino desejado, "
        "características pretendidas para as férias, duração em dias e se prefere dias de sol. Se faltar informação, "
        "formula as perguntas em português de forma direta. Se o cliente estiver aberto a sugestões, prossegue e assinala isso."
    )
    biblio_resp, biblio_samples = power_sampler.collect_during(lambda: biblio.call(task, txt))
    biblio.record_power(biblio_samples or power_map.get("biblio") or prompt_power_readings("biblio"))
    results["biblio"] = biblio_resp

    cultural = agents["cultural"]
    task = (
        "Identifica locais culturais relevantes para o destino indicado, incluindo custos financeiros, melhores horários e custos ambientais de cada deslocação. "
        "Se faltarem dados de destino, trabalha com pressupostos explícitos e diz que são pressupostos."
    )
    cultural_ctx = txt + "\n\n" + biblio_resp
    cultural_resp, cultural_samples = power_sampler.collect_during(lambda: cultural.call(task, cultural_ctx))
    cultural.record_power(cultural_samples or power_map.get("cultural") or prompt_power_readings("cultural"))
    results["cultural"] = cultural_resp

    natural = agents["natural"]
    task = (
        "Identifica locais naturais de interesse, como praias, jardins e florestas, e explica como viajar até lá, com custos económicos e ambientais de cada deslocação. "
        "Se faltarem dados de destino, usa pressupostos claros sem inventar informação como se fosse verificada."
    )
    natural_ctx = txt + "\n\n" + cultural_resp
    natural_resp, natural_samples = power_sampler.collect_during(lambda: natural.call(task, natural_ctx))
    natural.record_power(natural_samples or power_map.get("natural") or prompt_power_readings("natural"))
    results["natural"] = natural_resp

    hotel = agents["hotel"]
    task = (
        "Identifica um hotel de 3 estrelas com preocupações de sustentabilidade ambiental e inclui o link online do hotel. "
        "Apresenta o nome, localização, traços de sustentabilidade, e uma nota breve sobre porque é recomendado. "
        "Não contactes nenhuma empresa."
    )
    hotel_ctx = txt + "\n\n" + cultural_resp + "\n\n" + natural_resp
    hotel_resp, hotel_samples = power_sampler.collect_during(lambda: hotel.call(task, hotel_ctx))
    hotel.record_power(hotel_samples or power_map.get("hotel") or prompt_power_readings("hotel"))
    results["hotel"] = hotel_resp

    flight = agents["flight"]
    task = (
        "Identifica uma opção de viagem em avião em classe económica, com custos financeiros, custos ambientais, tempo estimado de viagem e horários. "
        "Se possível, inclui link oficial ou página pública de referência."
    )
    flight_ctx = txt + "\n\n" + hotel_resp
    flight_resp, flight_samples = power_sampler.collect_during(lambda: flight.call(task, flight_ctx))
    flight.record_power(flight_samples or power_map.get("flight") or prompt_power_readings("flight"))
    results["flight"] = flight_resp

    train = agents["train"]
    task = (
        "Identifica uma alternativa de viagem em comboio partindo da Amadora, com custos financeiros, custos ambientais, tempo estimado de viagem e horários. "
        "Se possível, inclui link oficial ou página pública de referência."
    )
    train_ctx = txt + "\n\n" + flight_resp
    train_resp, train_samples = power_sampler.collect_during(lambda: train.call(task, train_ctx))
    train.record_power(train_samples or power_map.get("train") or prompt_power_readings("train"))
    results["train"] = train_resp

    urls = []
    for value in [hotel_resp, cultural_resp, natural_resp, flight_resp, train_resp]:
        urls.extend(extract_urls(value))
    hotel_keywords = [hotel_resp, "hotel", "sustentabilidade", "3 estrelas"]
    url_checks = verify_urls(urls, hotel_keywords)

    report_writer = agents["orchestrator"]
    task = (
        "Compila um relatório final objetivo, profissional e organizado por tópicos com: perfil do cliente, "
        "respostas do perguntador, locais culturais, locais naturais, hotel recomendado, opções de avião e comboio, "
        "verificação anti-alucinação dos hotéis, relatório de transparência e sustentabilidade ambiental."
    )
    report_ctx = (
        txt
        + "\n\nPerguntas e contexto:\n"
        + biblio_resp
        + "\n\nCultural:\n"
        + cultural_resp
        + "\n\nNatural:\n"
        + natural_resp
        + "\n\nHotel:\n"
        + hotel_resp
        + "\n\nAvião:\n"
        + flight_resp
        + "\n\nComboio:\n"
        + train_resp
        + "\n\nVerificações:\n"
        + json.dumps(url_checks, ensure_ascii=False, indent=2)
    )
    final_report, report_samples = power_sampler.collect_during(lambda: report_writer.call(task, report_ctx))
    report_writer.record_power(report_samples or power_map.get("orchestrator") or prompt_power_readings("orchestrator"))
    results["final_report"] = final_report

    auditor = Agent("Agente H auditor", "Audita o relatório, verifica a sua qualidade e gera métrica de 0 a 10.")
    audit_task = (
        "Audita o relatório final e devolve uma métrica de 0 a 10. Indica também se cumpre linguagem direta, tópicos, transparência, sustentabilidade e links online dos hotéis."
    )
    audit_ctx = final_report + "\n\nPrompt:\n" + txt
    audit, auditor_samples = power_sampler.collect_during(lambda: auditor.call(audit_task, audit_ctx))
    auditor.record_power(auditor_samples or prompt_power_readings("auditor"))
    results["audit"] = audit

    score = None
    for line in audit.splitlines():
        if any(tok in line.lower() for tok in ("score", "rating", "nota", "métrica", "metrica")):
            import re
            m = re.search(r"(\d{1,2}(?:\.\d+)?)", line)
            if m:
                try:
                    score = float(m.group(1))
                    break
                except Exception:
                    pass

    if score is None:
        need_improve = "insufficient" in audit.lower() or "low" in audit.lower() or "fraco" in audit.lower()
    else:
        need_improve = score < args.improve_threshold

    if args.force_improve:
        need_improve = True

    print(f"Audit score: {score if score is not None else 'n/a'}; improver threshold: {args.improve_threshold}; force_improve={args.force_improve}")

    if need_improve:
        improver = agents["biblio"]
        task = "Melhora o relatório com base na auditoria e mantém um resumo curto das alterações."
        improve_ctx = final_report + "\n\nAuditoria:\n" + audit
        improved_report, improver_samples = power_sampler.collect_during(lambda: improver.call(task, improve_ctx))
        improver.record_power(improver_samples or power_map.get("biblio") or prompt_power_readings("biblio"))
        results["report_improved"] = improved_report
    else:
        print("Improver skipped because audit score did not cross the threshold.")
        results["report_improved"] = final_report

    metrics = {
        "total_messages": sum(a.messages for a in agents.values()) + auditor.messages,
        "latency_per_agent": {name: a.total_time for name, a in agents.items()} | {"auditor": auditor.total_time},
        "total_latency_s": sum(a.total_time for a in agents.values()) + auditor.total_time,
        "power_per_agent": {
            name: {
                "power_min_w": a.power_min_w,
                "power_avg_w": a.power_avg_w,
                "power_max_w": a.power_max_w,
                "wh": a.energy_wh,
                "kwh": a.energy_kwh,
            }
            for name, a in agents.items()
        } | {
            "auditor": {
                "power_min_w": auditor.power_min_w,
                "power_avg_w": auditor.power_avg_w,
                "power_max_w": auditor.power_max_w,
                "wh": auditor.energy_wh,
                "kwh": auditor.energy_kwh,
            }
        },
        "total_energy_wh": sum(a.energy_wh for a in agents.values()) + auditor.energy_wh,
        "total_energy_kwh": sum(a.energy_kwh for a in agents.values()) + auditor.energy_kwh,
        "url_checks": url_checks,
    }

    timestamp = time.strftime("%Y%m%d_%H%M%S")
    out_path = OUTPUT_DIR / f"prompt3_turismo_report_{timestamp}.md"
    lines_out: List[str] = []
    lines_out.append(f"# Relatório — MAS prompt férias para LLM local — {timestamp}")
    lines_out.append("")
    lines_out.append("## Prompt original")
    lines_out.append(txt)
    lines_out.append("")
    lines_out.append("## Orquestração")
    lines_out.append(results["orchestration"])
    lines_out.append("")
    lines_out.append("## Perguntador")
    lines_out.append(results["biblio"])
    lines_out.append("")
    lines_out.append("## Locais culturais")
    lines_out.append(results["cultural"])
    lines_out.append("")
    lines_out.append("## Locais naturais")
    lines_out.append(results["natural"])
    lines_out.append("")
    lines_out.append("## Hotel recomendado")
    lines_out.append(results["hotel"])
    lines_out.append("")
    lines_out.append("## Avião")
    lines_out.append(results["flight"])
    lines_out.append("")
    lines_out.append("## Comboio")
    lines_out.append(results["train"])
    lines_out.append("")
    lines_out.append("## Verificação anti-alucinação")
    if url_checks:
        lines_out.append(json.dumps(url_checks, indent=2, ensure_ascii=False))
    else:
        lines_out.append("Sem links para verificar.")
    lines_out.append("")
    lines_out.append("## Relatório final")
    lines_out.append(results["final_report"])
    lines_out.append("")
    lines_out.append("## Auditoria")
    lines_out.append(results["audit"])
    lines_out.append("")
    if results.get("report_improved") and results["report_improved"] != results["final_report"]:
        lines_out.append("## Relatório melhorado")
        lines_out.append(results["report_improved"])
        lines_out.append("")
    lines_out.append("## Métricas")
    lines_out.append(json.dumps(metrics, indent=2, ensure_ascii=False))
    lines_out.append("")
    lines_out.append("## Energia elétrica")
    for name, agent in {**agents, "auditor": auditor}.items():
        lines_out.append(
            f"- {name}: min {agent.power_min_w:.3f} W, avg {agent.power_avg_w:.3f} W, max {agent.power_max_w:.3f} W, "
            f"{agent.energy_wh:.6f} Wh, {agent.energy_kwh:.9f} kWh"
        )
    lines_out.append(f"- total: {metrics['total_energy_wh']:.6f} Wh, {metrics['total_energy_kwh']:.9f} kWh")

    out_path.write_text("\n\n".join(lines_out), encoding="utf-8")
    print("Saved report to", out_path)
    print("Metrics:", json.dumps(metrics, indent=2, ensure_ascii=False))


if __name__ == "__main__":
    main()
