#!/usr/bin/env python3
"""
Run the exact multi-agent investor workflow for `MAS investidor C para LLM local`.

The script uses local Ollama (llama3:latest) and keeps the prompt text verbatim.
It mirrors the named agents from the brief and saves outputs beside this file.

Usage: python prompt_2_test/run_prompt2_agents.py
"""
from __future__ import annotations
import argparse
import json
import pathlib
import subprocess
import time
import threading
import urllib.error
import urllib.request
from typing import Dict, List, Optional, Sequence


OLLAMA_ENDPOINT = "http://localhost:11434/api/generate"
MODEL_NAME = "llama3:latest"
WORKDIR = pathlib.Path(__file__).parent.parent
PROMPT_FILE = WORKDIR / "Caso investimento" / "MAS investidor C para LLM local.txt"
OUTPUT_DIR = pathlib.Path(__file__).parent


def parse_power_readings(raw_value: str) -> List[float]:
    parts = [part.strip() for part in raw_value.split(",") if part.strip()]
    if not parts:
        raise ValueError("empty power reading input")
    return [float(part) for part in parts]


def summarize_power_readings(readings: Sequence[float]) -> Dict[str, float]:
    if not readings:
        raise ValueError("at least one power reading is required")
    power_min = min(readings)
    power_max = max(readings)
    power_avg = sum(readings) / len(readings)
    return {
        "power_min_w": power_min,
        "power_avg_w": power_avg,
        "power_max_w": power_max,
    }


def energy_from_power(power_avg_w: float, elapsed_s: float) -> Dict[str, float]:
    watt_hours = power_avg_w * (elapsed_s / 3600.0)
    return {"wh": watt_hours, "kwh": watt_hours / 1000.0}


def prompt_power_readings(agent_name: str) -> List[float]:
    print()
    print(f"GPU power readings for {agent_name} (W).")
    print("If OpenHardwareMonitor is running with WMI enabled, the script will use GPU power automatically.")
    print("Otherwise enter one or more GPU wattage values separated by commas, for example: 118, 121, 119")
    print("If you only have one stable reading, enter a single number.")
    while True:
        raw_value = input(f"{agent_name} GPU watts: ").strip()
        try:
            return parse_power_readings(raw_value)
        except Exception:
            print("Invalid input. Please enter one or more numeric values separated by commas.")


def load_power_map(power_file: Optional[pathlib.Path]) -> Dict[str, List[float]]:
    if power_file is None:
        return {}
    data = json.loads(power_file.read_text(encoding="utf-8"))
    power_map: Dict[str, List[float]] = {}
    for agent_name, raw_value in data.items():
        if isinstance(raw_value, (int, float)):
            power_map[agent_name] = [float(raw_value)]
        elif isinstance(raw_value, list):
            power_map[agent_name] = [float(item) for item in raw_value]
        elif isinstance(raw_value, str):
            power_map[agent_name] = parse_power_readings(raw_value)
        else:
            raise ValueError(f"Unsupported power value for {agent_name}: {type(raw_value)!r}")
    return power_map


def query_openhardwaremonitor_sensors() -> List[Dict[str, object]]:
    command = [
        "powershell",
        "-NoProfile",
        "-Command",
        (
            "Get-CimInstance -Namespace root\\OpenHardwareMonitor -ClassName Sensor | "
            "Select-Object Name, SensorType, Value, Min, Max, Identifier | ConvertTo-Json -Depth 3"
        ),
    ]
    completed = subprocess.run(command, capture_output=True, text=True, check=True)
    raw_output = completed.stdout.strip()
    if not raw_output:
        return []
    data = json.loads(raw_output)
    if isinstance(data, dict):
        return [data]
    return list(data)


def find_gpu_power_readings_from_ohm() -> Dict[str, List[float]]:
    try:
        sensors = query_openhardwaremonitor_sensors()
    except Exception:
        return {}

    gpu_keywords = ("gpu", "nvidia", "amd", "ati", "radeon")
    power_keywords = ("power", "board power", "gpu power")
    readings_by_agent: Dict[str, List[float]] = {}

    for sensor in sensors:
        name = str(sensor.get("Name", ""))
        sensor_type = str(sensor.get("SensorType", ""))
        identifier = str(sensor.get("Identifier", ""))
        value = sensor.get("Value")
        haystack = f"{name} {sensor_type} {identifier}".lower()
        if not any(keyword in haystack for keyword in gpu_keywords):
            continue
        if not any(keyword in haystack for keyword in power_keywords):
            continue
        if value is None:
            continue
        try:
            numeric_value = float(value)
        except Exception:
            continue
        readings_by_agent.setdefault("gpu", []).append(numeric_value)

    return readings_by_agent


def read_current_gpu_power_watts() -> Optional[float]:
    try:
        sensors = query_openhardwaremonitor_sensors()
    except Exception:
        return None

    gpu_keywords = ("gpu", "nvidia", "amd", "ati", "radeon")
    power_keywords = ("power", "board power", "gpu power")
    values: List[float] = []

    for sensor in sensors:
        name = str(sensor.get("Name", ""))
        sensor_type = str(sensor.get("SensorType", ""))
        identifier = str(sensor.get("Identifier", ""))
        value = sensor.get("Value")
        haystack = f"{name} {sensor_type} {identifier}".lower()
        if not any(keyword in haystack for keyword in gpu_keywords):
            continue
        if not any(keyword in haystack for keyword in power_keywords):
            continue
        if value is None:
            continue
        try:
            values.append(float(value))
        except Exception:
            continue

    if not values:
        return None
    return sum(values) / len(values)


class PowerSampler:
    def __init__(self, interval_s: float = 0.5):
        self.interval_s = interval_s
        self.samples: List[float] = []
        self._stop_event = threading.Event()
        self._thread: Optional[threading.Thread] = None

    def start(self) -> None:
        self._stop_event.clear()
        self.samples = []
        self._thread = threading.Thread(target=self._run, daemon=True)
        self._thread.start()

    def stop(self) -> None:
        self._stop_event.set()
        if self._thread is not None:
            self._thread.join(timeout=max(1.0, self.interval_s * 4))
            self._thread = None

    def _run(self) -> None:
        while not self._stop_event.is_set():
            value = read_current_gpu_power_watts()
            if value is not None:
                self.samples.append(value)
            self._stop_event.wait(self.interval_s)

    def collect_during(self, work_fn):
        self.start()
        try:
            result = work_fn()
        finally:
            self.stop()
        if not self.samples:
            fallback = read_current_gpu_power_watts()
            if fallback is not None:
                self.samples.append(fallback)
        return result, list(self.samples)


def call_ollama(prompt_text: str, timeout: int = 600) -> str:
    payload = {"model": MODEL_NAME, "prompt": prompt_text, "stream": False}
    data = json.dumps(payload).encode("utf-8")
    req = urllib.request.Request(
        OLLAMA_ENDPOINT, data=data, headers={"Content-Type": "application/json"}, method="POST"
    )
    try:
        with urllib.request.urlopen(req, timeout=timeout) as resp:
            body = resp.read().decode("utf-8")
    except urllib.error.HTTPError as e:
        detail = e.read().decode("utf-8", errors="replace")
        raise RuntimeError(f"HTTP {e.code} from Ollama: {detail}") from e
    except urllib.error.URLError as e:
        raise RuntimeError(f"Cannot reach Ollama at {OLLAMA_ENDPOINT}: {e.reason}") from e

    parsed = json.loads(body)
    return parsed.get("response", "")


class Agent:
    def __init__(self, name: str, role_description: str):
        self.name = name
        self.role_description = role_description
        self.messages = 0
        self.total_time = 0.0
        self.power_readings: List[float] = []
        self.power_min_w = 0.0
        self.power_avg_w = 0.0
        self.power_max_w = 0.0
        self.energy_wh = 0.0
        self.energy_kwh = 0.0

    def call(self, task: str, context: str = "") -> str:
        prompt = f"Role: {self.name}\nDescription: {self.role_description}\nTask: {task}\nContext:\n{context}\n\nProvide a clear and concise answer."
        start = time.perf_counter()
        resp = call_ollama(prompt)
        elapsed = time.perf_counter() - start
        self.messages += 1
        self.total_time += elapsed
        return resp.strip()

    def record_power(self, readings: Sequence[float]) -> None:
        summary = summarize_power_readings(readings)
        energy = energy_from_power(summary["power_avg_w"], self.total_time)
        self.power_readings = [float(item) for item in readings]
        self.power_min_w = summary["power_min_w"]
        self.power_avg_w = summary["power_avg_w"]
        self.power_max_w = summary["power_max_w"]
        self.energy_wh = energy["wh"]
        self.energy_kwh = energy["kwh"]


def build_agents() -> Dict[str, Agent]:
    return {
        "agente_1": Agent("Agente 1", "Guarda a hora e minutos iniciais de execução desta prompt."),
        "agente_2": Agent(
            "Agente 2 Confirmador",
            "Caso o utilizador refira que o investimento deve ser na compra de outra moeda, pede para confirmar. Caso o utilizador refira que as ações a estudar são outras, pede para confirmar.",
        ),
        "agente_3": Agent(
            "Agente 3 EUR/USD",
            "Guarda informação no último mês relativa à taxa de câmbio euro/dólar.",
        ),
        "agente_4": Agent(
            "Agente 4 Impostos e Custos",
            "Guarda informação relativa aos impostos e custos de transação existentes na compra e venda de USD com EUR, por exemplo no banco Montepio.",
        ),
        "agente_5": Agent(
            "Agente 5 Sugestão de Transações",
            "Sugere um conjunto de transações para os próximos 30 dias, tendo em conta a identificação de oportunidades passadas nos 30 dias anteriores à execução desta prompt, de tal forma a obter 500 euros de lucro. Indica montante total investido no total das transações e por transação.",
        ),
        "agente_9": Agent("Agente 9 Explicador", "Explica o porquê de cada transação."),
        "agente_10": Agent(
            "Agente 10 Redator",
            "Redige um relatório em linguagem acessível a todos os investidores com toda a informação obtida, em pdf.",
        ),
        "agente_11": Agent(
            "Agente 11 Amigo do Ambiente",
            "Calcula valores totais e por agente de consumo de eletricidade utilizando codecarbon e latência desta prompt, e redige relatório.",
        ),
    }


def extract_urls(text: str) -> List[str]:
    import re

    return re.findall(r"https?://[^\s)\]]+", text)


def verify_urls(urls: Sequence[str]) -> List[Dict[str, str]]:
    results: List[Dict[str, str]] = []
    for url in urls:
        try:
            with urllib.request.urlopen(url, timeout=30) as resp:
                body = resp.read(4000).decode("utf-8", errors="replace")
            status = "sim" if body.strip() else "não"
            results.append({"url": url, "teste_alucinacao": status})
        except Exception as exc:
            results.append({"url": url, "teste_alucinacao": f"não ({exc.__class__.__name__})"})
    return results


def main():
    parser = argparse.ArgumentParser(description="Run the investor prompt 2 multi-agent workflow with local Ollama.")
    parser.add_argument(
        "--power-file",
        type=pathlib.Path,
        default=None,
        help="Optional JSON file with GPU wattage readings per agent name.",
    )
    parser.add_argument(
        "--force-improve",
        action="store_true",
        help="Force the improver agent to run even if the audit score is above threshold.",
    )
    parser.add_argument(
        "--improve-threshold",
        type=float,
        default=6.0,
        help="Audit score threshold below which the improver runs (default: 6.0).",
    )
    args = parser.parse_args()

    txt = PROMPT_FILE.read_text(encoding="utf-8", errors="replace")
    OUTPUT_DIR.mkdir(parents=True, exist_ok=True)
    agents = build_agents()
    power_map = load_power_map(args.power_file)
    power_sampler = PowerSampler(interval_s=0.5)

    # Save an exact snapshot of the prompt file so we can verify it was used verbatim
    timestamp = time.strftime("%Y%m%d_%H%M%S")
    prompt_snapshot = OUTPUT_DIR / f"prompt2_prompt_snapshot_{timestamp}.txt"
    prompt_snapshot.write_text(txt, encoding="utf-8")
    print("Saved prompt snapshot to", prompt_snapshot)

    results: Dict[str, str] = {}

    # 1) Agente 1: regista a hora e minutos iniciais.
    agente_1 = agents["agente_1"]
    task = "Regista a hora e os minutos iniciais de execução desta prompt, em português, num formato curto e claro."
    start_ctx = txt
    agente_1_resp, agente_1_samples = power_sampler.collect_during(lambda: agente_1.call(task, start_ctx))
    agente_1.record_power(agente_1_samples or power_map.get("agente_1") or prompt_power_readings("agente_1"))
    results["agente_1"] = agente_1_resp

    # 2) Agente 2: confirmação.
    agente_2 = agents["agente_2"]
    task = (
        "Analisa a prompt e confirma se existe ambiguidade sobre a moeda ou ativos a estudar. "
        "Se o utilizador referir compra de outra moeda ou ações diferentes, pede confirmação. "
        "Caso contrário, responde que está confirmado."
    )
    agente_2_resp, agente_2_samples = power_sampler.collect_during(lambda: agente_2.call(task, txt))
    agente_2.record_power(agente_2_samples or power_map.get("agente_2") or prompt_power_readings("agente_2"))
    results["agente_2"] = agente_2_resp

    # 3) Agente 3: taxa de câmbio EUR/USD do último mês.
    agente_3 = agents["agente_3"]
    task = (
        "Com base na prompt, resume a informação do último mês relativa à taxa de câmbio euro/dólar. "
        "Se não tiveres dados reais, sinaliza claramente que a informação deve ser obtida online e não inventes números."
    )
    agente_3_resp, agente_3_samples = power_sampler.collect_during(lambda: agente_3.call(task, txt))
    agente_3.record_power(agente_3_samples or power_map.get("agente_3") or prompt_power_readings("agente_3"))
    results["agente_3"] = agente_3_resp

    # 4) Agente 4: impostos e custos.
    agente_4 = agents["agente_4"]
    task = (
        "Resume impostos, comissões e custos de transação na compra e venda de USD com EUR, "
        "incluindo um exemplo como o banco Montepio. Se não tiveres dados reais, indica que é necessária validação online."
    )
    agente_4_resp, agente_4_samples = power_sampler.collect_during(lambda: agente_4.call(task, txt))
    agente_4.record_power(agente_4_samples or power_map.get("agente_4") or prompt_power_readings("agente_4"))
    results["agente_4"] = agente_4_resp

    # 5) Agente 5: transações para 500 euros.
    agente_5 = agents["agente_5"]
    task = (
        "Sugere um conjunto de transações para os próximos 30 dias, tendo em conta oportunidades dos 30 dias anteriores, "
        "para tentar obter 500 euros de lucro. Indica o montante total investido e o montante por transação. "
        "Mantém linguagem acessível e não inventes retornos impossíveis; explica as premissas."
    )
    agente_5_ctx = txt + "\n\n" + agente_3_resp + "\n\n" + agente_4_resp
    agente_5_resp, agente_5_samples = power_sampler.collect_during(lambda: agente_5.call(task, agente_5_ctx))
    agente_5.record_power(agente_5_samples or power_map.get("agente_5") or prompt_power_readings("agente_5"))
    results["agente_5"] = agente_5_resp

    # 6) Agente 9: explicador.
    agente_9 = agents["agente_9"]
    task = "Explica o porquê de cada transação sugerida, de forma sucinta e direta."
    agente_9_ctx = agente_5_resp + "\n\n" + agente_3_resp + "\n\n" + agente_4_resp
    agente_9_resp, agente_9_samples = power_sampler.collect_during(lambda: agente_9.call(task, agente_9_ctx))
    agente_9.record_power(agente_9_samples or power_map.get("agente_9") or prompt_power_readings("agente_9"))
    results["agente_9"] = agente_9_resp

    # 7) Agente 10: redator.
    agente_10 = agents["agente_10"]
    task = (
        "Redige um relatório em linguagem acessível a todos os investidores, em português, com toda a informação obtida. "
        "Inclui secções para objetivo, confirmação, taxa EUR/USD, impostos/custos, transações propostas, explicação, "
        "transparência, sustentabilidade e verificação de alucinações. Prepara o texto para exportação em PDF."
    )
    agente_10_ctx = txt + "\n\n" + "\n\n".join([agente_1_resp, agente_2_resp, agente_3_resp, agente_4_resp, agente_5_resp, agente_9_resp])
    report_v1, agente_10_samples = power_sampler.collect_during(lambda: agente_10.call(task, agente_10_ctx))
    agente_10.record_power(agente_10_samples or power_map.get("agente_10") or prompt_power_readings("agente_10"))
    results["report_v1"] = report_v1

    # 8) Verificação de alucinações e links.
    urls = []
    for value in [agente_3_resp, agente_4_resp, agente_5_resp, agente_9_resp, report_v1]:
        urls.extend(extract_urls(value))
    url_checks = verify_urls(urls)

    # 9) Agente 11: sustentabilidade.
    agente_11 = agents["agente_11"]
    task = (
        "Calcula os valores totais e por agente de consumo de eletricidade e latência desta prompt. "
        "Redige um relatório final com S1 total de latência, S2 latência por agente e S3 texto conclusivo."
    )
    sustentabilidade_ctx = report_v1 + "\n\n" + json.dumps(url_checks, ensure_ascii=False, indent=2)
    agente_11_resp, agente_11_samples = power_sampler.collect_during(lambda: agente_11.call(task, sustentabilidade_ctx))
    agente_11.record_power(agente_11_samples or power_map.get("agente_11") or prompt_power_readings("agente_11"))
    results["agente_11"] = agente_11_resp

    # Compute metrics.
    metrics = {
        "total_messages": sum(a.messages for a in agents.values()),
        "latency_per_agent": {name: a.total_time for name, a in agents.items()},
        "total_latency_s": sum(a.total_time for a in agents.values()),
        "power_per_agent": {
            name: {
                "power_min_w": a.power_min_w,
                "power_avg_w": a.power_avg_w,
                "power_max_w": a.power_max_w,
                "wh": a.energy_wh,
                "kwh": a.energy_kwh,
            }
            for name, a in agents.items()
        },
        "total_energy_wh": sum(a.energy_wh for a in agents.values()),
        "total_energy_kwh": sum(a.energy_kwh for a in agents.values()),
        "url_checks": url_checks,
    }

    timestamp = time.strftime("%Y%m%d_%H%M%S")
    out_path = OUTPUT_DIR / f"MAS_investidor_C_para_LLM_local_{timestamp}.md"
    lines_out: List[str] = []
    lines_out.append(f"# Relatório — MAS investidor C para LLM local — {timestamp}")
    lines_out.append("")
    lines_out.append("## Prompt original")
    lines_out.append(txt)
    lines_out.append("")
    lines_out.append("## Agente 1")
    lines_out.append(results["agente_1"])
    lines_out.append("")
    lines_out.append("## Agente 2")
    lines_out.append(results["agente_2"])
    lines_out.append("")
    lines_out.append("## Agente 3")
    lines_out.append(results["agente_3"])
    lines_out.append("")
    lines_out.append("## Agente 4")
    lines_out.append(results["agente_4"])
    lines_out.append("")
    lines_out.append("## Agente 5")
    lines_out.append(results["agente_5"])
    lines_out.append("")
    lines_out.append("## Agente 9")
    lines_out.append(results["agente_9"])
    lines_out.append("")
    lines_out.append("## Agente 10")
    lines_out.append(results["report_v1"])
    lines_out.append("")
    lines_out.append("## Verificação de alucinações")
    if url_checks:
        lines_out.append(json.dumps(url_checks, indent=2, ensure_ascii=False))
    else:
        lines_out.append("Sem links para verificar.")
    lines_out.append("")
    lines_out.append("## Agente 11")
    lines_out.append(results["agente_11"])
    lines_out.append("")

    lines_out.append("## Metrics")
    lines_out.append(json.dumps(metrics, indent=2))

    lines_out.append("")
    lines_out.append("## Electricity usage")
    for name, agent in agents.items():
        lines_out.append(
            f"- {name}: min {agent.power_min_w:.3f} W, avg {agent.power_avg_w:.3f} W, max {agent.power_max_w:.3f} W, "
            f"{agent.energy_wh:.6f} Wh, {agent.energy_kwh:.9f} kWh"
        )
    lines_out.append(f"- total: {metrics['total_energy_wh']:.6f} Wh, {metrics['total_energy_kwh']:.9f} kWh")

    out_path.write_text("\n\n".join(lines_out), encoding="utf-8")
    print("Saved report to", out_path)
    print("Metrics:", json.dumps(metrics, indent=2))


if __name__ == "__main__":
    main()
