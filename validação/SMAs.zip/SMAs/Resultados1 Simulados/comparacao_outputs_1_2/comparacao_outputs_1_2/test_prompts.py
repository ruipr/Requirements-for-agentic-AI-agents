#!/usr/bin/env python3
"""
Runner simples para executar prompts em Ollama local (llama3:latest)
sem API key, via http://localhost:11434/api/generate.

coloca este script na mesma pasta onde estao as pastas "Caso investigador", "Caso investimento" e "Caso turismo" (ou ajusta os caminhos no código)
e executa com: python test_prompts.py --batch (para executar os 3 casos predefinidos) ou python test_prompts.py "caminho/para/prompt.txt" (para executar um caso específico)
"""

import argparse
import json
import pathlib
import sys
import time
import urllib.error
import urllib.request


def call_ollama(prompt_text: str, model: str, host: str, timeout: int) -> str:
    endpoint = host.rstrip("/") + "/api/generate"
    payload = {
        "model": model,
        "prompt": prompt_text,
        "stream": False,
    }

    data = json.dumps(payload).encode("utf-8")
    req = urllib.request.Request(
        endpoint,
        data=data,
        headers={"Content-Type": "application/json"},
        method="POST",
    )

    try:
        with urllib.request.urlopen(req, timeout=timeout) as resp:
            body = resp.read().decode("utf-8")
    except urllib.error.HTTPError as e:
        detail = e.read().decode("utf-8", errors="replace")
        raise RuntimeError(f"HTTP {e.code} no Ollama: {detail}") from e
    except urllib.error.URLError as e:
        raise RuntimeError(
            f"Nao foi possivel ligar ao Ollama em {endpoint}. Erro: {e.reason}"
        ) from e

    parsed = json.loads(body)
    return parsed.get("response", "")


def build_output_path(prompt_file: pathlib.Path, output_dir: pathlib.Path) -> pathlib.Path:
    output_dir.mkdir(parents=True, exist_ok=True)
    timestamp = time.strftime("%Y%m%d_%H%M%S")
    safe_name = prompt_file.stem.replace(" ", "_")
    return output_dir / f"{safe_name}_{timestamp}.md"


def main() -> int:
    parser = argparse.ArgumentParser(
        description="Executa um ficheiro de prompt num Ollama local"
    )
    parser.add_argument(
        "prompt_file",
        nargs='?',
        default=None,
        help="Caminho para o .txt com a prompt (ou vazio se usar --batch)",
    )
    parser.add_argument(
        "--batch",
        action="store_true",
        help="Executa os 3 casos predefinidos em modo interativo",
    )
    parser.add_argument(
        "--model",
        default="llama3:latest",
        help="Modelo no Ollama (default: llama3:latest)",
    )
    parser.add_argument(
        "--host",
        default="http://localhost:11434",
        help="Host do Ollama (default: http://localhost:11434)",
    )
    parser.add_argument(
        "--timeout",
        type=int,
        default=600,
        help="Timeout em segundos (default: 600)",
    )
    parser.add_argument(
        "--output-dir",
        default="outputs",
        help="Diretoria para guardar resposta (default: outputs)",
    )
    args = parser.parse_args()

    # helper: predefined prompts for batch mode
    predefined_prompts = [
        pathlib.Path("Caso investigador") / "prompt 1 transparency gaps LLM local.txt",
        pathlib.Path("Caso investimento") / "MAS investidor C para LLM local.txt",
        pathlib.Path("Caso turismo") / "MAS prompt férias para LLM local.txt",
    ]

    def ask_energy_readings(case_display: str):
        print()
        print(f"Insira leituras de 'Power (W)' para: {case_display} (GPU se aplicável)")
        print("Formato: x, y, y, ..., y, z  (x=min, z=max, y=leituras intermédias a usar para média)")
        print("Exemplo: 5.2, 7.1, 6.9, 8.0")
        s = input("Leituras: ").strip()
        parts = [p.strip() for p in s.split(",") if p.strip()]
        try:
            nums = [float(p) for p in parts]
        except Exception:
            print("Entrada inválida — tente novamente com números separados por vírgula.")
            return ask_energy_readings(case_display)
        if len(nums) < 2:
            print("É preciso pelo menos dois números (min e max). Tente de novo.")
            return ask_energy_readings(case_display)
        # compute mean of middle values if present
        if len(nums) >= 3:
            middle = nums[1:-1]
            mean_mid = sum(middle) / len(middle)
        else:
            mean_mid = (nums[0] + nums[-1]) / 2.0
        return nums[0], mean_mid, nums[-1]

    def ask_feedback(case_display: str):
        print()
        print(f"Agora: Confirmar se a resposta de {case_display} inclui os campos pedidos.")
        fields = [
            "Tarefas e ferramentas utilizadas",
            "Número de mensagens entre agentes",
            "Latência total e por agente",
            "Relatório final e cumprimento dos requisitos",
        ]
        fb = {}
        for f in fields:
            print()
            print(f"{f} — escreva texto (ou deixe em branco):")
            val = input(f"{f}: ")
            fb[f] = val.strip()
        return fb

    results = []

    to_run = []
    if args.batch:
        to_run = predefined_prompts
    elif args.prompt_file:
        to_run = [pathlib.Path(args.prompt_file)]
    else:
        print("ERRO: nenhum ficheiro especificado. Use um ficheiro posicional ou --batch.")
        return 1

    for prompt_path in to_run:
        if not prompt_path.exists():
            print(f"AVISO: prompt não encontrada: {prompt_path}. Pulo este caso.")
            continue

        print()
        print("=== Próximo caso ===")
        print(f"Ficheiro: {prompt_path}")
        print("Antes de iniciar, prepare o OpenHardwareMonitor para registar 'CPU Package (W)'.")
        print("Quando estiver pronto, prima Enter para iniciar a execução (Ctrl+C para cancelar).")
        input("Prima Enter para iniciar...")

        prompt_text = prompt_path.read_text(encoding="utf-8", errors="replace")
        start = time.perf_counter()
        print("Waiting for model response...")
        sys.stdout.flush()
        try:
            response = call_ollama(prompt_text, args.model, args.host, args.timeout)
        except Exception as exc:
            print(f"ERRO na execucao: {exc}")
            continue
        end = time.perf_counter()
        elapsed = end - start

        # save individual response
        output_path = build_output_path(prompt_path, pathlib.Path(args.output_dir))
        report_lines = []
        report_lines.append(f"# Resultado: {prompt_path.name}")
        report_lines.append("")
        report_lines.append("## Condicoes de execucao")
        report_lines.append(f"- Modelo: {args.model}")
        report_lines.append(f"- Host Ollama: {args.host}")
        report_lines.append(f"- Ficheiro de prompt: {prompt_path}")
        report_lines.append(f"- Início (epoch s): {start:.3f}")
        report_lines.append(f"- Fim (epoch s): {end:.3f}")
        report_lines.append(f"- Latencia total (s): {elapsed:.3f}")
        report_lines.append("")
        report_lines.append("## Resposta do modelo")
        report_lines.append("")
        report_lines.append(response.strip() if response.strip() else "(sem resposta)")
        report_lines.append("")
        output_path.write_text("\n".join(report_lines), encoding="utf-8")
        print(f"OK: resposta guardada em {output_path}")

        # ask for energy readings
        w_min, w_mean, w_max = ask_energy_readings(prompt_path.name)
        hours = elapsed / 3600.0
        wh = w_mean * hours
        kwh = wh / 1000.0

        # ask for feedback fields
        feedback = ask_feedback(prompt_path.name)

        results.append({
            "case": prompt_path.name,
            "prompt_file": str(prompt_path),
            "model": args.model,
            "host": args.host,
            "start": start,
            "end": end,
            "latency_s": elapsed,
            "w_min": w_min,
            "w_mean": w_mean,
            "w_max": w_max,
            "wh": wh,
            "kwh": kwh,
            "output_path": str(output_path),
            "feedback": feedback,
        })

    # after loop, create comparative markdown
    if results:
        comp_path = pathlib.Path(args.output_dir) / f"comparative_{time.strftime('%Y%m%d_%H%M%S')}.md"
        lines = []
        lines.append("# Relatório comparativo")
        lines.append("")
        # table header
        headers = [
            "Caso",
            "Prompt",
            "Latência (s)",
            "W_min",
            "W_mean",
            "W_max",
            "Wh",
            "kWh",
            "Resposta"
        ]
        lines.append("| " + " | ".join(headers) + " |")
        lines.append("|" + "---|" * len(headers))
        for r in results:
            row = [
                r['case'],
                r['prompt_file'],
                f"{r['latency_s']:.3f}",
                f"{r['w_min']:.3f}",
                f"{r['w_mean']:.3f}",
                f"{r['w_max']:.3f}",
                f"{r['wh']:.6f}",
                f"{r['kwh']:.9f}",
                r['output_path'],
            ]
            lines.append("| " + " | ".join(row) + " |")

        lines.append("")
        lines.append("## Feedback detalhado por caso")
        for r in results:
            lines.append("")
            lines.append(f"### {r['case']}")
            lines.append("")
            lines.append(f"- Output: {r['output_path']}")
            lines.append(f"- Latência (s): {r['latency_s']:.3f}")
            lines.append(f"- W_min: {r['w_min']:.3f}")
            lines.append(f"- W_mean: {r['w_mean']:.3f}")
            lines.append(f"- W_max: {r['w_max']:.3f}")
            lines.append(f"- Wh: {r['wh']:.6f}")
            lines.append(f"- kWh: {r['kwh']:.9f}")
            lines.append("")
            lines.append("**Feedback:**")
            for k, v in r['feedback'].items():
                lines.append(f"- {k}: {v if v else '(vazio)'}")

        comp_path.write_text("\n".join(lines), encoding="utf-8")
        print(f"Relatório comparativo guardado em {comp_path}")

    print("Tudo feito.")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
