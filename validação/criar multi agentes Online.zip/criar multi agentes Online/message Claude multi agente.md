# Como criar um sistema multi-agente com Claude

Um sistema multi-agente envolve vários "agentes" Claude a colaborarem, cada um com um papel específico, comunicando entre si para resolver tarefas complexas. Aqui vai um guia prático.

## Arquitetura típica

A abordagem mais comum é o padrão **orchestrator-workers** (orquestrador-trabalhadores):

- **Orquestrador (lead agent):** recebe a tarefa, decompõe-na em subtarefas e delega.
- **Subagentes (workers):** executam subtarefas em paralelo, cada um com o seu próprio contexto e ferramentas.
- **Agente sintetizador:** consolida os resultados (pode ser o próprio orquestrador).

Esta é a arquitetura que a Anthropic usa no sistema de Research do Claude.

## Componentes essenciais

1. **SDK e modelo:** usa o SDK oficial (`anthropic` em Python ou TypeScript) com modelos como `claude-sonnet-4` ou `claude-opus-4`.
2. **Tool use:** cada agente expõe ferramentas (functions) que pode chamar — incluindo a ferramenta de "criar subagente".
3. **Memória partilhada:** um store (Redis, ficheiros, base de dados) para passar contexto entre agentes sem encher a janela de contexto.
4. **Loop de execução:** cada agente corre num loop até decidir que terminou.

## Exemplo mínimo em Python

```python
from anthropic import Anthropic
import json

client = Anthropic()
MODEL = "claude-sonnet-4-5"

def run_subagent(task: str, role: str) -> str:
    """Executa um subagente com uma tarefa específica."""
    system = f"És um agente especializado em: {role}. Responde de forma concisa."
    response = client.messages.create(
        model=MODEL,
        max_tokens=2048,
        system=system,
        messages=[{"role": "user", "content": task}],
    )
    return response.content[0].text

# Ferramenta exposta ao orquestrador
tools = [{
    "name": "delegate_task",
    "description": "Delega uma subtarefa a um agente especializado.",
    "input_schema": {
        "type": "object",
        "properties": {
            "task": {"type": "string", "description": "A subtarefa a executar"},
            "role": {"type": "string", "description": "Especialidade do agente"},
        },
        "required": ["task", "role"],
    },
}]

def orchestrate(user_query: str):
    messages = [{"role": "user", "content": user_query}]
    system = (
        "És um orquestrador. Decompõe a tarefa do utilizador em subtarefas "
        "e delega cada uma a um subagente usando delegate_task. "
        "No final, sintetiza os resultados numa resposta única."
    )

    while True:
        resp = client.messages.create(
            model=MODEL,
            max_tokens=4096,
            system=system,
            tools=tools,
            messages=messages,
        )

        if resp.stop_reason == "end_turn":
            return resp.content[-1].text

        # Processa tool calls
        messages.append({"role": "assistant", "content": resp.content})
        tool_results = []
        for block in resp.content:
            if block.type == "tool_use":
                result = run_subagent(block.input["task"], block.input["role"])
                tool_results.append({
                    "type": "tool_result",
                    "tool_use_id": block.id,
                    "content": result,
                })
        messages.append({"role": "user", "content": tool_results})

if __name__ == "__main__":
    print(orchestrate("Compara Python, Rust e Go para backend web em 2025."))
```

Neste exemplo, o orquestrador decide quantos subagentes lançar (por exemplo, um por linguagem) e depois sintetiza.

## Boas práticas

- **Paralelização:** lança subagentes em paralelo com `asyncio` ou `ThreadPoolExecutor`. Reduz latência drasticamente em tarefas de pesquisa.
- **Prompts claros por papel:** cada subagente deve ter objetivo, formato de saída e critério de "concluído" bem definidos.
- **Orçamento de tokens/iterações:** limita o número de subagentes e profundidade para evitar custos explosivos. Sistemas multi-agente consomem ~15× mais tokens que um chat normal.
- **Isolamento de contexto:** o orquestrador não vê todo o contexto dos workers — só os resumos. Isto evita poluição e mantém escalabilidade.
- **Avaliação:** testa com casos onde a resposta correta é conhecida; usa LLM-as-judge para tarefas abertas.
- **Tratamento de falhas:** se um subagente falhar, o orquestrador deve poder repetir ou seguir sem ele.

## Frameworks que ajudam

Se não queres construir tudo de raiz:

- **Claude Agent SDK** (oficial da Anthropic) — abstrai o loop de agente, gestão de ferramentas e memória.
- **LangGraph** — bom para grafos de agentes com estado.
- **CrewAI** — orientado a "equipas" de agentes com papéis.
- **Model Context Protocol (MCP)** — padrão da Anthropic para conectar agentes a ferramentas e fontes de dados externas de forma uniforme.

## Quando *não* usar multi-agente

Para tarefas sequenciais simples ou onde cada passo depende fortemente do anterior, um único agente com bom prompt e ferramentas costuma ser mais barato e fiável. Multi-agente brilha em tarefas **paralelizáveis** com subtarefas independentes (pesquisa, análise comparativa, exploração de hipóteses).

Queres que aprofunde alguma parte — por exemplo, paralelização com `asyncio`, integração MCP, ou um exemplo concreto para um caso de uso teu?