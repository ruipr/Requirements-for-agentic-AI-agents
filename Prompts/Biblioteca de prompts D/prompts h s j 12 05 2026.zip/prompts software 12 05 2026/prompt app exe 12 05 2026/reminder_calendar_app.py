"""
Reminder Calendar Application
=============================

This module implements a simple desktop calendar application using Python's
built‑in ``tkinter`` GUI toolkit.  The program displays a calendar for a
selected year, allows the user to record events on specific dates and
provides reminder pop‑ups on the day of an event and the day before.

Key features
------------

* **Calendar view** – the main window shows all 12 months of the chosen year
  laid out in a grid.  Each month includes clickable day cells.
* **Event storage** – events are stored in a JSON file in the user's home
  directory.  Each date may hold multiple event descriptions.
* **Reminders** – upon startup and periodically thereafter the application
  checks for events occurring today and tomorrow.  If found, a pop‑up
  message box appears detailing the events.
* **Language support** – text in the UI can be toggled between Portuguese
  and English.  A button in the top bar switches the language at run time.
* **Simple design** – the interface uses only basic widgets and text to
  satisfy the user's request for minimalism.

The application is meant to be packaged into a standalone executable using
PyInstaller.  While PyInstaller isn't available in this environment, the
code is structured to work out of the box on Windows 10 when packaged
externally.  To build an executable, run the following command in a
Windows command prompt after installing PyInstaller::

    pyinstaller --noconsole --onefile --name ReminderCalendar reminder_calendar_app.py

This will produce a ``ReminderCalendar.exe`` in the ``dist`` directory.

Author: ChatGPT
License: Public Domain
"""

import json
import os
import sys
import datetime
import calendar
import tkinter as tk
from tkinter import messagebox
from typing import Dict, List, Tuple


class EventStore:
    """Simple JSON‑backed storage for calendar events.

    The storage file is created in the user's home directory under
    ``.reminder_calendar_events.json``.  Events are stored as a mapping
    from ISO date strings (``YYYY‑MM‑DD``) to lists of event strings.
    """

    def __init__(self, filename: str = None) -> None:
        home = os.path.expanduser("~")
        if filename is None:
            filename = os.path.join(home, ".reminder_calendar_events.json")
        self.filename = filename
        self.events: Dict[str, List[str]] = {}
        self._load()

    def _load(self) -> None:
        """Load events from disk if the file exists."""
        if os.path.exists(self.filename):
            try:
                with open(self.filename, "r", encoding="utf‑8") as f:
                    data = json.load(f)
                    if isinstance(data, dict):
                        self.events = {k: list(v) for k, v in data.items()}
            except Exception:
                # Ignore corrupt files
                self.events = {}

    def _save(self) -> None:
        """Persist events to disk atomically."""
        tmpfile = self.filename + ".tmp"
        with open(tmpfile, "w", encoding="utf‑8") as f:
            json.dump(self.events, f, ensure_ascii=False, indent=2)
        os.replace(tmpfile, self.filename)

    def get_events(self, date_str: str) -> List[str]:
        """Return a list of events for the given ISO date string."""
        return list(self.events.get(date_str, []))

    def add_event(self, date_str: str, event: str) -> None:
        """Add an event for the given date and persist the change."""
        self.events.setdefault(date_str, []).append(event)
        self._save()

    def remove_event(self, date_str: str, event: str) -> None:
        """Remove an event from the given date and persist the change."""
        events = self.events.get(date_str)
        if events and event in events:
            events.remove(event)
            if not events:
                self.events.pop(date_str, None)
            self._save()


class LanguageTexts:
    """Container for UI text in Portuguese and English."""

    def __init__(self) -> None:
        # Each entry maps a key to a tuple (English, Portuguese)
        self.strings: Dict[str, Tuple[str, str]] = {
            "title": ("Reminder Calendar", "Calendário de Lembretes"),
            "select_year": ("Select Year", "Selecionar Ano"),
            "add_event": ("Add event", "Adicionar evento"),
            "events_today": ("Events today", "Eventos de hoje"),
            "events_tomorrow": ("Events tomorrow", "Eventos de amanhã"),
            "no_events": ("No events", "Sem eventos"),
            "enter_event": ("Enter event description", "Insira a descrição do evento"),
            "event_added": ("Event added", "Evento adicionado"),
            "event_removed": ("Event removed", "Evento removido"),
            "delete_selected": ("Delete selected", "Eliminar selecionado"),
            "language": ("PT/EN", "EN/PT"),
        }
        # 0 for English, 1 for Portuguese
        self.lang_index = 0

    def toggle(self) -> None:
        """Switch between English and Portuguese."""
        self.lang_index = 1 - self.lang_index

    def __call__(self, key: str) -> str:
        """Retrieve the text for the current language."""
        if key in self.strings:
            return self.strings[key][self.lang_index]
        return key


class ReminderCalendarApp:
    """Main application class."""

    def __init__(self, root: tk.Tk) -> None:
        self.root = root
        self.store = EventStore()
        self.texts = LanguageTexts()
        self.current_year = datetime.date.today().year
        # Draw UI and schedule reminders
        self._build_ui()
        # Start periodic reminder checks
        self.root.after(1000, self.check_reminders)

    def _build_ui(self) -> None:
        """Construct all widgets in the main window."""
        self.root.title(self.texts("title"))
        # Top bar for year selection and language toggle
        top_frame = tk.Frame(self.root)
        top_frame.pack(pady=10)

        # Year label and spinbox
        year_label = tk.Label(top_frame, text=self.texts("select_year"))
        year_label.pack(side=tk.LEFT, padx=5)
        self.year_var = tk.IntVar(value=self.current_year)
        year_spin = tk.Spinbox(
            top_frame,
            from_=1900,
            to=2100,
            textvariable=self.year_var,
            width=5,
            command=self.refresh_calendar,
        )
        year_spin.pack(side=tk.LEFT, padx=5)

        # Language toggle button
        lang_btn = tk.Button(top_frame, text=self.texts("language"), command=self.toggle_language)
        lang_btn.pack(side=tk.LEFT, padx=5)

        # Frame for months
        self.month_frame = tk.Frame(self.root)
        self.month_frame.pack(pady=10)
        # Draw initial calendar
        self.draw_calendar()

    def toggle_language(self) -> None:
        """Handle language toggling and refresh UI text."""
        self.texts.toggle()
        self.root.title(self.texts("title"))
        # Re‑draw calendar to update all labels
        for widget in self.month_frame.winfo_children():
            widget.destroy()
        self.draw_calendar()

    def refresh_calendar(self) -> None:
        """Refresh calendar when year selection changes."""
        try:
            self.current_year = int(self.year_var.get())
        except ValueError:
            return
        for widget in self.month_frame.winfo_children():
            widget.destroy()
        self.draw_calendar()

    def draw_calendar(self) -> None:
        """Render the entire year's calendar in a 3x4 grid."""
        for month in range(1, 13):
            row = (month - 1) // 3
            col = (month - 1) % 3
            frame = tk.Frame(self.month_frame, borderwidth=1, relief=tk.RIDGE)
            frame.grid(row=row, column=col, padx=5, pady=5, sticky="nsew")

            # Month name
            month_name = calendar.month_name[month]
            lbl = tk.Label(frame, text=month_name, font=("Arial", 12, "bold"))
            lbl.pack()

            # Days header
            tbl = tk.Frame(frame)
            tbl.pack()
            days = list(calendar.day_abbr)
            for i, day in enumerate(days):
                day_lbl = tk.Label(tbl, text=day, width=3, font=("Arial", 8, "bold"))
                day_lbl.grid(row=0, column=i)
            # Fill in the days
            month_cal = calendar.monthcalendar(self.current_year, month)
            for r, week in enumerate(month_cal, start=1):
                for c, day_num in enumerate(week):
                    txt = str(day_num) if day_num != 0 else ""
                    cell = tk.Label(
                        tbl,
                        text=txt,
                        width=3,
                        height=1,
                        borderwidth=1,
                        relief=tk.FLAT,
                        bg="white" if day_num != 0 else "lightgray",
                    )
                    cell.grid(row=r, column=c, padx=1, pady=1)
                    if day_num != 0:
                        date_str = f"{self.current_year:04d}-{month:02d}-{day_num:02d}"
                        cell.bind(
                            "<Button-1>",
                            lambda e, d=date_str: self.open_event_editor(d),
                        )
                        # Highlight days that have events
                        if self.store.get_events(date_str):
                            cell.config(bg="#ffc")

    def open_event_editor(self, date_str: str) -> None:
        """Create a modal window to view and modify events for a date."""
        events = self.store.get_events(date_str)
        win = tk.Toplevel(self.root)
        win.title(f"{self.texts('add_event')} - {date_str}")
        win.grab_set()

        tk.Label(win, text=date_str, font=("Arial", 10, "bold")).pack(pady=5)
        list_frame = tk.Frame(win)
        list_frame.pack(pady=5)
        listbox = tk.Listbox(list_frame, width=40, height=5)
        listbox.pack(side=tk.LEFT)
        for ev in events:
            listbox.insert(tk.END, ev)
        scrollbar = tk.Scrollbar(list_frame, command=listbox.yview)
        scrollbar.pack(side=tk.RIGHT, fill=tk.Y)
        listbox.config(yscrollcommand=scrollbar.set)

        entry = tk.Entry(win, width=40)
        entry.pack(pady=5)

        def add_event() -> None:
            text = entry.get().strip()
            if text:
                self.store.add_event(date_str, text)
                listbox.insert(tk.END, text)
                entry.delete(0, tk.END)
                messagebox.showinfo(self.texts("event_added"), self.texts("event_added"))
                self.refresh_calendar()

        def delete_selected() -> None:
            sel = listbox.curselection()
            if sel:
                item = listbox.get(sel[0])
                self.store.remove_event(date_str, item)
                listbox.delete(sel[0])
                messagebox.showinfo(self.texts("event_removed"), self.texts("event_removed"))
                self.refresh_calendar()

        btn_frame = tk.Frame(win)
        btn_frame.pack(pady=5)
        tk.Button(btn_frame, text=self.texts("add_event"), command=add_event).pack(side=tk.LEFT, padx=5)
        tk.Button(btn_frame, text=self.texts("delete_selected"), command=delete_selected).pack(side=tk.LEFT, padx=5)

    def check_reminders(self) -> None:
        """Check today's and tomorrow's events and show pop‑ups accordingly."""
        today = datetime.date.today()
        tomorrow = today + datetime.timedelta(days=1)
        for date_obj, label_key in [
            (today, "events_today"),
            (tomorrow, "events_tomorrow"),
        ]:
            date_str = date_obj.isoformat()
            events = self.store.get_events(date_str)
            if events:
                header = self.texts(label_key)
                message = f"{header} ({date_str}):\n" + "\n".join(f"- {ev}" for ev in events)
                messagebox.showinfo(header, message)
        # Schedule the next reminder check in one hour
        self.root.after(3600000, self.check_reminders)


def main() -> None:
    """Entry point for the application."""
    root = tk.Tk()
    ReminderCalendarApp(root)
    root.mainloop()


if __name__ == "__main__":
    main()