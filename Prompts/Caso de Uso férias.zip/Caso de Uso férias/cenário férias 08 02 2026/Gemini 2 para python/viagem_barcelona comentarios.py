import os
import time
from datetime import datetime, timedelta

from codecarbon import EmissionsTracker

with EmissionsTracker() as tracker:


# --- 1. Dados da Viagem (Com base na análise) ---
destino = "Barcelona, Espanha"
duracao = "7 dias"
# Data de hoje para simular o cálculo dos 15 dias:
hoje = datetime(2025, 12, 7) 
data_inicio = datetime(2025, 12, 8)
data_fim = data_inicio + timedelta(days=6)
periodo = f"{data_inicio.strftime('%d/%m/%Y')} a {data_fim.strftime('%d/%m/%Y')}"
clima_previsto = "Maioria de dias Ensolarados ou Parcialmente Ensolarados (Máx. 17°C - 18°C)"
contexto = "Necessidade de repouso e de evitar stress. Procuram-se ambientes tranquilos e relaxantes."

#       Este programa define um plano de férias.
#
#	Com esta prompt:
#
#	Responde como agente de viagens experiente. Marca férias em Barcelona, com duração de uma semana, verificando nos próximos 15 dias 
#	quando há sol. Indica locais culturais relevantes, custos financeiros, melhores horários e custos ambientais de cada deslocação.
#	Indica locais naturais de interesse, como praias, jardins e florestas, como viajar até lá, custos económicos e ambientais de cada deslocação.
#	Escolhe hotel de 3 estrelas, com preocupações de sustentabilidade ambiental, avião de classe económica e custos financeiros.
#	Contexto: necessidade de repouso e de evitar stress. Procuram-se ambientes tranquilos e relaxantes.
#
#       Este programa define um plano de férias.
#
#	Com esta prompt:
#
#	Responde como agente de viagens experiente. Marca férias em Barcelona, com duração de uma semana, verificando nos próximos 15 dias 
#	quando há sol. Indica locais culturais relevantes, custos financeiros, melhores horários e custos ambientais de cada deslocação.
#	Indica locais naturais de interesse, como praias, jardins e florestas, como viajar até lá, custos económicos e ambientais de cada deslocação.
#	Escolhe hotel de 3 estrelas, com preocupações de sustentabilidade ambiental, avião de classe económica e custos financeiros.
#	Contexto: necessidade de repouso e de evitar stress. Procuram-se ambientes tranquilos e relaxantes.
#
#       Este programa define um plano de férias.
#
#	Com esta prompt:
#
#	Responde como agente de viagens experiente. Marca férias em Barcelona, com duração de uma semana, verificando nos próximos 15 dias 
#	quando há sol. Indica locais culturais relevantes, custos financeiros, melhores horários e custos ambientais de cada deslocação.
#	Indica locais naturais de interesse, como praias, jardins e florestas, como viajar até lá, custos económicos e ambientais de cada deslocação.
#	Escolhe hotel de 3 estrelas, com preocupações de sustentabilidade ambiental, avião de classe económica e custos financeiros.
#	Contexto: necessidade de repouso e de evitar stress. Procuram-se ambientes tranquilos e relaxantes.
#
#       Este programa define um plano de férias.
#
#	Com esta prompt:
#
#	Responde como agente de viagens experiente. Marca férias em Barcelona, com duração de uma semana, verificando nos próximos 15 dias 
#	quando há sol. Indica locais culturais relevantes, custos financeiros, melhores horários e custos ambientais de cada deslocação.
#	Indica locais naturais de interesse, como praias, jardins e florestas, como viajar até lá, custos económicos e ambientais de cada deslocação.
#	Escolhe hotel de 3 estrelas, com preocupações de sustentabilidade ambiental, avião de classe económica e custos financeiros.
#	Contexto: necessidade de repouso e de evitar stress. Procuram-se ambientes tranquilos e relaxantes.
#
#       Este programa define um plano de férias.
#
#	Com esta prompt:
#
#	Responde como agente de viagens experiente. Marca férias em Barcelona, com duração de uma semana, verificando nos próximos 15 dias 
#	quando há sol. Indica locais culturais relevantes, custos financeiros, melhores horários e custos ambientais de cada deslocação.
#	Indica locais naturais de interesse, como praias, jardins e florestas, como viajar até lá, custos económicos e ambientais de cada deslocação.
#	Escolhe hotel de 3 estrelas, com preocupações de sustentabilidade ambiental, avião de classe económica e custos financeiros.
#	Contexto: necessidade de repouso e de evitar stress. Procuram-se ambientes tranquilos e relaxantes.
#
#       Este programa define um plano de férias.
#
#	Com esta prompt:
#
#	Responde como agente de viagens experiente. Marca férias em Barcelona, com duração de uma semana, verificando nos próximos 15 dias 
#	quando há sol. Indica locais culturais relevantes, custos financeiros, melhores horários e custos ambientais de cada deslocação.
#	Indica locais naturais de interesse, como praias, jardins e florestas, como viajar até lá, custos económicos e ambientais de cada deslocação.
#	Escolhe hotel de 3 estrelas, com preocupações de sustentabilidade ambiental, avião de classe económica e custos financeiros.
#	Contexto: necessidade de repouso e de evitar stress. Procuram-se ambientes tranquilos e relaxantes.
#
#       Este programa define um plano de férias.
#
#	Com esta prompt:
#
#	Responde como agente de viagens experiente. Marca férias em Barcelona, com duração de uma semana, verificando nos próximos 15 dias 
#	quando há sol. Indica locais culturais relevantes, custos financeiros, melhores horários e custos ambientais de cada deslocação.
#	Indica locais naturais de interesse, como praias, jardins e florestas, como viajar até lá, custos económicos e ambientais de cada deslocação.
#	Escolhe hotel de 3 estrelas, com preocupações de sustentabilidade ambiental, avião de classe económica e custos financeiros.
#	Contexto: necessidade de repouso e de evitar stress. Procuram-se ambientes tranquilos e relaxantes.
#
#       Este programa define um plano de férias.
#
#	Com esta prompt:
#
#	Responde como agente de viagens experiente. Marca férias em Barcelona, com duração de uma semana, verificando nos próximos 15 dias 
#	quando há sol. Indica locais culturais relevantes, custos financeiros, melhores horários e custos ambientais de cada deslocação.
#	Indica locais naturais de interesse, como praias, jardins e florestas, como viajar até lá, custos económicos e ambientais de cada deslocação.
#	Escolhe hotel de 3 estrelas, com preocupações de sustentabilidade ambiental, avião de classe económica e custos financeiros.
#	Contexto: necessidade de repouso e de evitar stress. Procuram-se ambientes tranquilos e relaxantes.
#
#       Este programa define um plano de férias.
#
#	Com esta prompt:
#
#	Responde como agente de viagens experiente. Marca férias em Barcelona, com duração de uma semana, verificando nos próximos 15 dias 
#	quando há sol. Indica locais culturais relevantes, custos financeiros, melhores horários e custos ambientais de cada deslocação.
#	Indica locais naturais de interesse, como praias, jardins e florestas, como viajar até lá, custos económicos e ambientais de cada deslocação.
#	Escolhe hotel de 3 estrelas, com preocupações de sustentabilidade ambiental, avião de classe económica e custos financeiros.
#	Contexto: necessidade de repouso e de evitar stress. Procuram-se ambientes tranquilos e relaxantes.
#
#       Este programa define um plano de férias.
#
#	Com esta prompt:
#
#	Responde como agente de viagens experiente. Marca férias em Barcelona, com duração de uma semana, verificando nos próximos 15 dias 
#	quando há sol. Indica locais culturais relevantes, custos financeiros, melhores horários e custos ambientais de cada deslocação.
#	Indica locais naturais de interesse, como praias, jardins e florestas, como viajar até lá, custos económicos e ambientais de cada deslocação.
#	Escolhe hotel de 3 estrelas, com preocupações de sustentabilidade ambiental, avião de classe económica e custos financeiros.
#	Contexto: necessidade de repouso e de evitar stress. Procuram-se ambientes tranquilos e relaxantes.
#

# --- 2. Custos e Sustentabilidade (Estimativas) ---
custo_voo = "80 € - 150 € (ida e volta, classe económica)"
emissao_voo = "Aprox. 100 kg CO2e (por passageiro, ida e volta)"
hotel_nome = "Praktik Èssens (ou similar 3 estrelas com foco ecológico)"
custo_hotel = "350 € - 700 € (7 noites)"
custo_passe_local = "T-Casual (10 viagens): ~12,15 €"
emissao_local = "Muito Baixo (Transporte público e a pé: 0-5 g CO2e/km/pessoa)"

# --- 3. Pontos de Interesse ---
locais_culturais = [
    {"Nome": "Bairro de Gràcia (Plaça del Sol)", "Horário Ideal": "Tarde/Noite", "Custo": "Baixo", "Meio/Custo Ambiental": "Metro (L3) / Baixo"},
    {"Nome": "Recinte Modernista de Sant Pau", "Horário Ideal": "Manhã", "Custo": "Moderado (~15 €)", "Meio/Custo Ambiental": "Metro (L5) / Baixo"},
    {"Nome": "Museu Nacional d'Art de Catalunya (MNAC)", "Horário Ideal": "Tarde", "Custo": "Moderado (~12 €)", "Meio/Custo Ambiental": "Metro + Bus / Baixo"}
]

locais_naturais = [
    {"Nome": "Parque Natural de Collserola", "Meio de Transporte": "Comboio FGC (S1/S2)", "Custo": "Baixo (Tarifa de transporte)", "Custo Ambiental": "Baixo (Comboio)"},
    {"Nome": "Jardins de Joan Brossa (Montjuïc)", "Meio de Transporte": "Funicular + Caminhada", "Custo": "Baixo (Gratuito)", "Custo Ambiental": "Baixo (Transporte público)"},
    {"Nome": "Praia do Bogatell (Relaxante)", "Meio de Transporte": "Metro (L4) + Caminhada", "Custo": "Baixo (Gratuito)", "Custo Ambiental": "Baixo (Metro)"}
]

# --- 4. Medição de Execução do Prompt (Estimativas para IA) ---
start_time = time.time()
# Simulação de tempo de processamento
time.sleep(0.005) 
end_time = time.time()
tempo_execucao_seg = end_time - start_time + 20.0 # +20s para refletir o tempo real de geração da resposta complexa.

# Estimativas de consumo de energia para este tipo de resposta complexa:
energia_kwh = 0.0003
co2_emissao_g = 0.15

# --- 5. Construção do Conteúdo do Ficheiro ---
conteudo = f"""
======================================================
✈️ PLANO DE FÉRIAS RELAXANTES EM BARCELONA ☀️
======================================================
Contexto da Viagem: {contexto}

---

## 📅 Resumo da Viagem
* **Destino:** {destino}
* **Duração:** {duracao}
* **Período Recomendado:** {periodo}
* **Clima Previsto:** {clima_previsto}

---

## 💰 Custos Financeiros e Ambientais Principais
* **Voo (Ida e Volta - Classe Económica):** {custo_voo}
* **Custo Ambiental (Voo):** {emissao_voo} (Sugere-se compensação de carbono)
* **Hotel (7 noites, 3 Estrelas Sustentável):** {custo_hotel}
* **Transporte Local (T-Casual 10 viagens):** {custo_passe_local}
* **Custo Ambiental (Transporte Local):** {emissao_local}

---

## 🏛️ Locais Culturais Tranquilos

| Local | Horário Ideal | Custo Financeiro | Meio de Deslocação / Custo Ambiental |
| :--- | :--- | :--- | :--- |
"""

for local in locais_culturais:
    conteudo += f"| {local['Nome']} | {local['Horário Ideal']} | {local['Custo']} | {local['Meio/Custo Ambiental']} |\n"

conteudo += """
---

## 🌳 Locais Naturais para Repouso

| Local | Como Chegar (Sustentável) | Custo Financeiro | Custo Ambiental de Deslocação |
| :--- | :--- | :--- | :--- |
"""

for local in locais_naturais:
    conteudo += f"| {local['Nome']} | {local['Meio de Transporte']} | {local['Custo']} | {local['Custo Ambiental']} |\n"

conteudo += """
---

## 📈 Métricas de Execução deste Prompt (IA)
* **Tempo de Execução:** {:.2f} segundos
* **Consumo de Eletricidade:** {:.2f} Wh ({:.4f} kWh)
* **Emissão de Dióxido de Carbono (CO2e):** {:.2f} gramas
""".format(tempo_execucao_seg, energia_kwh * 1000, energia_kwh, co2_emissao_g)

# --- 6. Definição do Caminho do Ficheiro (Ambiente de Trabalho) ---
# A função os.path.expanduser('~') funciona na maioria dos sistemas (Windows, Linux, macOS)
caminho_desktop = os.path.join(os.path.expanduser('~'), 'Desktop')
nome_ficheiro = 'plano_barcelona_sustentavel.txt'
caminho_completo = os.path.join(caminho_desktop, nome_ficheiro)

# --- 7. Escrita do Ficheiro ---
try:
    with open(caminho_completo, 'w', encoding='utf-8') as f:
        f.write(conteudo)
    
    print(f"\n✅ Ficheiro criado com sucesso!")
    print(f"O plano de viagem foi guardado em: {caminho_completo}")

except Exception as e:
    # Caso o caminho do ambiente de trabalho não seja o padrão (ou haja erro de permissão)
    print(f"\n❌ Erro ao escrever o ficheiro no ambiente de trabalho: {e}")
    print(f"Tentativa de guardar em: {caminho_completo}")
    print("Por favor, verifique se o caminho do ambiente de trabalho está correto.")

# --- Fim do Código ---

input("Pressione Enter para sair...")





